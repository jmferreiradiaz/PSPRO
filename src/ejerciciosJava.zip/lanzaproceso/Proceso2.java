package lanzaproceso;

import java.util.Scanner;

public class Proceso2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        System.out.println("El numero es "+numero);
    }
}
