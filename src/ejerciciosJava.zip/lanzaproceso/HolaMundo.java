package lanzaproceso;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class HolaMundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
}
