package lanzaproceso;

public class Proceso1 {
    public static void main(String[] args) {
        System.out.println(5);
    }
}
